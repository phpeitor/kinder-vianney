window._wpemojiSettings = {
    "baseUrl": "https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/72x72\/",
    "ext": ".png",
    "svgUrl": "https:\/\/s.w.org\/images\/core\/emoji\/16.0.1\/svg\/",
    "svgExt": ".svg",
    "source": {
        "concatemoji": ".\/js\/wp-emoji-release.min.js?ver=4bc7e34cee88072655e34415f8630486"
    }
    };

    var mytheme_urls = {
		 theme_base_url:'./'
 		,framework_base_url:'./'
 		,ajaxurl:'#'
 		,url:'#'
 		,scroll:'disable'
 		,stickynav:'enable'
 		,is_admin:''
 		,skin:'orange'
 		,layout:'wide'
 		,isResponsive:'enable'
 		,layout_pattern:''
	};

      /*! This file is auto-generated */
      ! function(s, n) {
        var o, i, e;

        function c(e) {
          try {
            var t = {
              supportTests: e,
              timestamp: (new Date).valueOf()
            };
            sessionStorage.setItem(o, JSON.stringify(t))
          } catch (e) {}
        }

        function p(e, t, n) {
          e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0);
          var t = new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data),
            a = (e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(n, 0, 0), new Uint32Array(e.getImageData(0, 0, e.canvas.width, e.canvas.height).data));
          return t.every(function(e, t) {
            return e === a[t]
          })
        }

        function u(e, t) {
          e.clearRect(0, 0, e.canvas.width, e.canvas.height), e.fillText(t, 0, 0);
          for (var n = e.getImageData(16, 16, 1, 1), a = 0; a < n.data.length; a++)
            if (0 !== n.data[a]) return !1;
          return !0
        }

        function f(e, t, n, a) {
          switch (t) {
            case "flag":
              return n(e, "\ud83c\udff3\ufe0f\u200d\u26a7\ufe0f", "\ud83c\udff3\ufe0f\u200b\u26a7\ufe0f") ? !1 : !n(e, "\ud83c\udde8\ud83c\uddf6", "\ud83c\udde8\u200b\ud83c\uddf6") && !n(e, "\ud83c\udff4\udb40\udc67\udb40\udc62\udb40\udc65\udb40\udc6e\udb40\udc67\udb40\udc7f", "\ud83c\udff4\u200b\udb40\udc67\u200b\udb40\udc62\u200b\udb40\udc65\u200b\udb40\udc6e\u200b\udb40\udc67\u200b\udb40\udc7f");
            case "emoji":
              return !a(e, "\ud83e\udedf")
          }
          return !1
        }

        function g(e, t, n, a) {
          var r = "undefined" != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope ? new OffscreenCanvas(300, 150) : s.createElement("canvas"),
            o = r.getContext("2d", {
              willReadFrequently: !0
            }),
            i = (o.textBaseline = "top", o.font = "600 32px Arial", {});
          return e.forEach(function(e) {
            i[e] = t(o, e, n, a)
          }), i
        }

        function t(e) {
          var t = s.createElement("script");
          t.src = e, t.defer = !0, s.head.appendChild(t)
        }
        "undefined" != typeof Promise && (o = "wpEmojiSettingsSupports", i = ["flag", "emoji"], n.supports = {
          everything: !0,
          everythingExceptFlag: !0
        }, e = new Promise(function(e) {
          s.addEventListener("DOMContentLoaded", e, {
            once: !0
          })
        }), new Promise(function(t) {
          var n = function() {
            try {
              var e = JSON.parse(sessionStorage.getItem(o));
              if ("object" == typeof e && "number" == typeof e.timestamp && (new Date).valueOf() < e.timestamp + 604800 && "object" == typeof e.supportTests) return e.supportTests
            } catch (e) {}
            return null
          }();
          if (!n) {
            if ("undefined" != typeof Worker && "undefined" != typeof OffscreenCanvas && "undefined" != typeof URL && URL.createObjectURL && "undefined" != typeof Blob) try {
              var e = "postMessage(" + g.toString() + "(" + [JSON.stringify(i), f.toString(), p.toString(), u.toString()].join(",") + "));",
                a = new Blob([e], {
                  type: "text/javascript"
                }),
                r = new Worker(URL.createObjectURL(a), {
                  name: "wpTestEmojiSupports"
                });
              return void(r.onmessage = function(e) {
                c(n = e.data), r.terminate(), t(n)
              })
            } catch (e) {}
            c(n = g(i, f, p, u))
          }
          t(n)
        }).then(function(e) {
          for (var t in e) n.supports[t] = e[t], n.supports.everything = n.supports.everything && n.supports[t], "flag" !== t && (n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && n.supports[t]);
          n.supports.everythingExceptFlag = n.supports.everythingExceptFlag && !n.supports.flag, n.DOMReady = !1, n.readyCallback = function() {
            n.DOMReady = !0
          }
        }).then(function() {
          return e
        }).then(function() {
          var e;
          n.supports.everything || (n.readyCallback(), (e = n.source || {}).concatemoji ? t(e.concatemoji) : e.wpemoji && e.twemoji && (t(e.twemoji), t(e.wpemoji)))
        }))
      }((window, document), window._wpemojiSettings);
      /* ]]> */